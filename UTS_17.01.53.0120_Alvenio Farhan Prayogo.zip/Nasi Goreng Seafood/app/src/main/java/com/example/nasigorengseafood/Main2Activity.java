package com.example.nasigorengseafood;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.audiofx.DynamicsProcessing;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    TextView txtJumlah,txtHarga, txtGetNama;
    EditText edtNama;
    CheckBox cbx_pedas, cbx_asin;
    int jumlah, total, harga=10, pedas, asin;
    String nama, statusPedas = "Tidak", statusAsin="tidak";
    boolean iscbx_pedas, isCbx_asin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txtJumlah = (TextView) findViewById(R.id.txt_jumlah);
        txtHarga = (TextView) findViewById(R.id.txt_price);
        edtNama = (EditText) findViewById(R.id.txt_nama);
        txtGetNama = (TextView) findViewById(R.id.txt_getNama);
        cbx_pedas = (CheckBox) findViewById(R.id.cbx_pedas);
        cbx_asin = (CheckBox) findViewById(R.id.cbx_asin);

        Button btnShare = (Button) findViewById(R.id.btnShare);
        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                // Mengisi pesan yang ingin di share
                intent.putExtra(intent.EXTRA_TEXT,"Hallo i can share to Social Media");
                intent.setType("text/plain");

                // Menjalankan perintah Intent Implicit
                startActivity(Intent.createChooser(intent,"Share to : "));

            }
        });
    }
    public void sambal(){
        if (cbx_pedas.isChecked()){
            iscbx_pedas=true;
            statusPedas="Sambal Tomat";
            pedas=1;
        }else{
            iscbx_pedas=false;
            statusPedas="";
            pedas=0;
        }
        if (cbx_asin.isChecked()){
            isCbx_asin=true;
            statusAsin="";
            asin=0;
        }
    }
    public void tambah (View view){
        jumlah = jumlah + 1;
        txtJumlah.setText(""+jumlah);
    }
    public void kurang (View view){
        jumlah = jumlah - 1;
        txtJumlah.setText (""+jumlah);
    }
    public void order (View view)  {display(harga);}
    public void display(int harga){
        sambal();
        total = jumlah*harga;
        if(iscbx_pedas){
            total += (jumlah * pedas);
        }
        if (isCbx_asin){
            total += (jumlah * asin);
        }
        Log.i( "harga :", "" +total);
        nama =edtNama.getText().toString();
        txtGetNama.setText("Nama :" +nama +
                "/n" +statusPedas+
                "/n" +statusAsin+
                "/nTeimakasih");
        txtHarga.setText("Harga : Rp."+total+"000");
    }

}
