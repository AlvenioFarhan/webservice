<?php
 define('HOST','localhost');
 define('USER','root');
 define('PASS','');
 define('DB','restoran');

 $con = mysqli_connect_errno(HOST,USER,PASS,DB) or die('Unable to Connect');